package com.devteria.identityservice.service;

import com.devteria.identityservice.dto.QualityOption;
import com.devteria.identityservice.helpers.DownloadHelper;
import com.devteria.identityservice.utils.FileUtils;
import com.devteria.identityservice.utils.M3U8Utils;
import com.devteria.identityservice.utils.RegexUtils;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
@Slf4j
public class M3U8DownloadService {

    private final DownloadHelper downloadHelper;

    private static final String BASE_SAVE_FOLDER = "local_copy";
    private static final int BATCH_SIZE = 10;
    private static final int MAX_CONCURRENT_DOWNLOADS = 20;
    private String MASTER_M3U8_URL_FORMAT = "https://main.24playerhd.com/newplaylist/%s/%s.m3u8";

    private final ExecutorService executorService = Executors.newFixedThreadPool(MAX_CONCURRENT_DOWNLOADS);

    /**
     * Tải và lưu video M3U8
     */
    public void downloadM3U8Video(String embedLink) {
        try {

            String id = this.extractIdFromEmbedLink(embedLink);
            String masterM3u8Url = this.generateMasterM3U8Url(id);

            log.info("🚀 Bắt đầu tải video M3U8: {}", masterM3u8Url);

            // 1) Tải master m3u8
            String masterContent = downloadHelper.downloadContent(masterM3u8Url);
            String masterLocalPath = M3U8Utils.urlToLocalPath(masterM3u8Url, BASE_SAVE_FOLDER);
            downloadHelper.downloadAndSaveFile(masterM3u8Url, masterLocalPath);

            // 2) Lấy danh sách m3u8 con
            List<String> variantPaths = M3U8Utils.getPathsFromM3U8(masterContent);
            List<QualityOption> qualityOptions = new ArrayList<>();

            for (String variantPath : variantPaths) {
                String variantUrl = M3U8Utils.resolveUrl(masterM3u8Url, variantPath);

                String variantContent = downloadHelper.downloadContent(variantUrl);

                // Ghi lại file m3u8 với đường dẫn local
                String localM3U8Path = M3U8Utils.urlToLocalPath(variantUrl, BASE_SAVE_FOLDER);
                String localM3U8Content = M3U8Utils.rewriteM3U8ToLocal(variantContent, variantUrl);
                FileUtils.saveFileContent(localM3U8Path, localM3U8Content);

                // Lưu option chất lượng cho index.html
                String label = M3U8Utils.getQualityLabel(masterContent, variantPath);
                qualityOptions.add(new QualityOption(label, localM3U8Path.replace(BASE_SAVE_FOLDER + "/", "")));

                // 3) Lấy danh sách segment
                List<String> segmentPaths = M3U8Utils.getPathsFromM3U8(variantContent);

                // Tải segment song song theo batch
                downloadSegmentsInBatches(segmentPaths, variantUrl);
            }
        } catch (Exception e) {
            log.error("❌ Lỗi khi tải video M3U8: {}", e.getMessage(), e);
            throw new RuntimeException("Lỗi khi tải video M3U8", e);
        }
    }

    /**
     * Tải segments theo batch
     */
    private void downloadSegmentsInBatches(List<String> segmentPaths, String variantUrl) {
        for (int i = 0; i < segmentPaths.size(); i += BATCH_SIZE) {
            int endIndex = Math.min(i + BATCH_SIZE, segmentPaths.size());
            List<String> batch = segmentPaths.subList(i, endIndex);

            List<CompletableFuture<Void>> futures = batch.stream()
                    .map(segPath -> {
                        String segUrl = M3U8Utils.resolveUrl(variantUrl, segPath);
                        return CompletableFuture.runAsync(() -> {
                            downloadHelper.downloadAndSaveFile(segUrl,
                                    M3U8Utils.urlToLocalPath(segUrl, BASE_SAVE_FOLDER));
                        }, executorService);
                    })
                    .collect(Collectors.toList());

            // Đợi batch hiện tại hoàn thành
            CompletableFuture.allOf(futures.toArray(new CompletableFuture[0])).join();
        }
    }

    /**
     * Trích xuất ID từ link embed 24playerhd
     * Ví dụ:
     * https://hot.24playerhd.com/public/dist/index.php?id=6718a8fbd0fb4944a72870bc3ba672bc&seek=0&seekmin=0
     * Trả về: 6718a8fbd0fb4944a72870bc3ba672bc
     */
    public String extractIdFromEmbedLink(String embedLink) {
        return RegexUtils.extractIdFromEmbedLink(embedLink);
    }

    /**
     * Tạo master M3U8 URL từ ID
     * Ví dụ: 6718a8fbd0fb4944a72870bc3ba672bc ->
     * https://main.24playerhd.com/newplaylist/6718a8fbd0fb4944a72870bc3ba672bc/6718a8fbd0fb4944a72870bc3ba672bc.m3u8
     */
    public String generateMasterM3U8Url(String id) {
        if (id == null || id.trim().isEmpty()) {
            throw new IllegalArgumentException("ID không được để trống");
        }

        String masterUrl = String.format(MASTER_M3U8_URL_FORMAT, id, id);
        log.info("✅ Đã tạo master M3U8 URL: {}", masterUrl);
        return masterUrl;
    }
}
