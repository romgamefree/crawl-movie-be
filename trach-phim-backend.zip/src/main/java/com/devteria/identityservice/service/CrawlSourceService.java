package com.devteria.identityservice.service;

import com.devteria.identityservice.constant.MovieStatus;
import com.devteria.identityservice.constant.MovieType;
import com.devteria.identityservice.constant.SelectorMovieDetail;
import com.devteria.identityservice.dto.request.CrawlSourceRequest;
import com.devteria.identityservice.dto.response.BulkInsertResponse;
import com.devteria.identityservice.dto.response.CrawlSourceResponse;
import com.devteria.identityservice.dto.response.MovieResponse;
import com.devteria.identityservice.entity.*;
import com.devteria.identityservice.exception.AppException;
import com.devteria.identityservice.exception.ErrorCode;
import com.devteria.identityservice.helpers.HtmlFetcherHelper;
import com.devteria.identityservice.helpers.MetadataHelper;
import com.devteria.identityservice.helpers.SeleniumHelper;
import com.devteria.identityservice.mapper.CrawlSourceMapper;
import com.devteria.identityservice.mapper.MovieMapper;
import com.devteria.identityservice.repository.*;
import com.devteria.identityservice.utils.StringUtils;
import lombok.AccessLevel;
import lombok.RequiredArgsConstructor;
import lombok.experimental.FieldDefaults;
import lombok.extern.slf4j.Slf4j;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
@FieldDefaults(level = AccessLevel.PRIVATE, makeFinal = true)
@Slf4j
public class CrawlSourceService {
    // mappers
    CrawlSourceMapper mapper;
    MovieMapper movieMapper;

    // repositories
    CrawlSourceRepository repository;
    SelectorRepository selectorRepository;
    MovieRepository movieRepository;
    ActorRepository actorRepository;
    CategoryRepository categoryRepository;
    CountryRepository countryRepository;
    DirectorRepository directorRepository;
    EpisodeRepository episodeRepository;
    ServerDataRepository serverDataRepository;

    // helpers
    HtmlFetcherHelper htmlFetcherHelper;
    MetadataHelper metadataHelper;
    SeleniumHelper seleniumHelper;

    // services
    M3U8DownloadService m3U8DownloadService;

    public CrawlSourceResponse create(CrawlSourceRequest request) {
        CrawlSource entity = mapper.toEntity(request);

        // Set Selector nếu có selectorId
        if (request.getSelectorId() != null) {
            entity.setSelector(selectorRepository.findById(request.getSelectorId())
                    .orElseThrow(() -> new AppException(ErrorCode.INVALID_KEY)));
        }

        if (entity.getBaseUrl() != null) {
            String info = metadataHelper.fetchTitleAndDescription(entity.getBaseUrl());
            if (info != null && !info.isBlank()) {
                entity.setNote(info);
            }
        }
        return mapper.toResponse(repository.save(entity));
    }

    public CrawlSourceResponse update(String id, CrawlSourceRequest request) {
        CrawlSource entity = repository.findById(id).orElseThrow(() -> new AppException(ErrorCode.INVALID_KEY));
        mapper.update(entity, request);

        // Set Selector nếu có selectorId
        if (request.getSelectorId() != null) {
            entity.setSelector(selectorRepository.findById(request.getSelectorId())
                    .orElseThrow(() -> new AppException(ErrorCode.INVALID_KEY)));
        } else {
            entity.setSelector(null);
        }

        if (entity.getBaseUrl() != null) {
            String info = metadataHelper.fetchTitleAndDescription(entity.getBaseUrl());
            if (info != null && !info.isBlank()) {
                entity.setNote(info);
            }
        }
        return mapper.toResponse(repository.save(entity));
    }

    public void delete(String id) {
        repository.deleteById(id);
    }

    public CrawlSourceResponse get(String id) {
        return mapper.toResponse(repository.findById(id).orElseThrow(() -> new AppException(ErrorCode.INVALID_KEY)));
    }

    public List<CrawlSourceResponse> list() {
        return repository.findAll().stream().map(mapper::toResponse).toList();
    }

    @Transactional
    public MovieResponse insertFromCrawlSource(String crawlSourceId) {
        CrawlSource crawlSource = repository.findById(crawlSourceId)
                .orElseThrow(() -> new AppException(ErrorCode.DATA_NOT_FOUND));

        // Kiểm tra xem đã được insert chưa
        if (crawlSource.getInserted()) {
            log.warn("⚠️ Crawl source đã được insert trước đó: {}", crawlSource.getBaseUrl());
            throw new AppException(ErrorCode.DATA_ALREADY_EXISTED);
        }

        Selector selector = crawlSource.getSelector();
        if (selector == null) {
            log.error("❌ Selector not found");
            throw new AppException(ErrorCode.DATA_NOT_FOUND);
        }
        Set<SelectorItem> selectorItems = selector.getSelectorItems();
        if (selectorItems == null || selectorItems.isEmpty()) {
            log.error("❌ Selector items not found");
            throw new AppException(ErrorCode.DATA_NOT_FOUND);
        }

        String baseUrl = crawlSource.getBaseUrl();

        log.info("🚀 Bắt đầu crawl dữ liệu từ URL: {}", baseUrl);

        try {
            // Thử fetch HTML thường trước
            String html = htmlFetcherHelper.fetchUrl(baseUrl);
            Document doc = Jsoup.parse(html, baseUrl);

            // Extract data using selector items
            Map<String, String> extractedData = extractDataFromSelectors(doc, selectorItems, baseUrl);

            // Kiểm tra xem có video URL không
            String videoUrl = extractedData.get(SelectorMovieDetail.VIDEO_URL.getValue());
            if (videoUrl == null || videoUrl.isBlank()) {
                log.info("⚠️ Không tìm thấy video URL, thử fetch với JavaScript...");
                
                // Thử fetch với JavaScript
                String jsHtml = htmlFetcherHelper.fetchUrlWithJs(baseUrl);
                if (jsHtml != null) {
                    Document jsDoc = Jsoup.parse(jsHtml, baseUrl);
                    Map<String, String> jsExtractedData = extractDataFromSelectors(jsDoc, selectorItems, baseUrl);
                    
                    // Merge data, ưu tiên dữ liệu từ JavaScript
                    for (Map.Entry<String, String> entry : jsExtractedData.entrySet()) {
                        if (entry.getValue() != null && !entry.getValue().isBlank()) {
                            extractedData.put(entry.getKey(), entry.getValue());
                        }
                    }
                    
                    log.info("✅ Đã merge dữ liệu từ JavaScript rendering");
                }
            }

            if (extractedData.isEmpty()) {
                log.warn("⚠️ Không tìm thấy dữ liệu nào từ selectors");
                throw new AppException(ErrorCode.DATA_NOT_FOUND);
            }

            log.info("📊 Dữ liệu đã extract: {}", extractedData);

            // Tạo hoặc tìm Movie dựa trên thumbnailUrl
            Movie movie = findOrCreateMovie(extractedData);

            // Lưu các entity liên quan
            saveRelatedEntities(movie, extractedData, baseUrl);

            // Đánh dấu đã insert thành công
            crawlSource.setInserted(true);
            repository.save(crawlSource);

            log.info("✅ Hoàn thành crawl và lưu dữ liệu cho movie: {}", movie.getTitle());

            return movieMapper.toResponse(movie);

        } catch (Exception e) {
            log.error("❌ Lỗi khi crawl dữ liệu từ URL {}: {}", baseUrl, e.getMessage(), e);
            throw new AppException(ErrorCode.DATA_NOT_FOUND);
        }
    }

    /**
     * Insert dữ liệu từ danh sách CrawlSource IDs cụ thể (chỉ những cái chưa được
     * insert)
     * 
     * @param crawlSourceIds Danh sách IDs của crawl sources cần xử lý
     * @return Thông tin chi tiết về quá trình insert
     */
    @Transactional
    public BulkInsertResponse insertFromCrawlSourceIds(List<String> crawlSourceIds) {
        long startTime = System.currentTimeMillis();
        log.info("🚀 Bắt đầu insert từ {} crawl source IDs", crawlSourceIds.size());

        int successCount = 0;
        int errorCount = 0;
        int skippedCount = 0;
        List<String> errorUrls = new ArrayList<>();
        List<String> skippedUrls = new ArrayList<>();

        for (int i = 0; i < crawlSourceIds.size(); i++) {
            String crawlSourceId = crawlSourceIds.get(i);

            try {
                // Kiểm tra xem crawl source đã được insert chưa
                CrawlSource crawlSource = repository.findById(crawlSourceId)
                        .orElseThrow(() -> new AppException(ErrorCode.DATA_NOT_FOUND));

                if (crawlSource.getInserted()) {
                    skippedCount++;
                    skippedUrls.add(crawlSource.getBaseUrl());
                    log.info("⏭️ Bỏ qua crawl source đã được insert: {}", crawlSource.getBaseUrl());
                    continue;
                }

                log.info("📝 Đang xử lý crawl source {}/{}: ID {}", i + 1, crawlSourceIds.size(), crawlSourceId);

                MovieResponse movieResponse = insertFromCrawlSource(crawlSourceId);
                successCount++;

                // Đánh dấu đã insert thành công
                crawlSource.setInserted(true);
                repository.save(crawlSource);

                log.info("✅ Thành công: ID {} -> {}", crawlSourceId, movieResponse.getTitle());

            } catch (Exception e) {
                errorCount++;
                errorUrls.add("ID: " + crawlSourceId + " - " + e.getMessage());
                log.error("❌ Lỗi khi xử lý crawl source ID {}: {}", crawlSourceId, e.getMessage());
            }

            // Log progress mỗi 10 records
            if ((i + 1) % 10 == 0) {
                log.info("📊 Tiến độ: {}/{} (thành công: {}, lỗi: {}, bỏ qua: {})",
                        i + 1, crawlSourceIds.size(), successCount, errorCount, skippedCount);
            }
        }

        long processingTime = System.currentTimeMillis() - startTime;

        log.info("🎉 Hoàn thành! Tổng kết: {}/{} thành công, {} lỗi, {} bỏ qua trong {}ms",
                successCount, crawlSourceIds.size(), errorCount, skippedCount, processingTime);

        if (!errorUrls.isEmpty()) {
            log.warn("⚠️ Các crawl source bị lỗi: {}", errorUrls);
        }

        if (!skippedUrls.isEmpty()) {
            log.info("ℹ️ Các crawl source đã được insert trước đó: {}", skippedUrls);
        }

        return BulkInsertResponse.builder()
                .totalSources(crawlSourceIds.size())
                .successCount(successCount)
                .errorCount(errorCount)
                .errorUrls(errorUrls)
                .message(String.format("Đã xử lý %d crawl sources: %d thành công, %d lỗi, %d bỏ qua trong %dms",
                        crawlSourceIds.size(), successCount, errorCount, skippedCount, processingTime))
                .processingTimeMs(processingTime)
                .build();
    }

    /**
     * Extract dữ liệu từ HTML document sử dụng các selector items
     */
    private Map<String, String> extractDataFromSelectors(Document doc, Set<SelectorItem> selectorItems,
            String baseUrl) {
        Map<String, String> extractedData = new HashMap<>();

        for (SelectorItem selectorItem : selectorItems) {
            String name = selectorItem.getName();
            String query = selectorItem.getQuery();
            String attribute = selectorItem.getAttribute();
            Boolean isList = selectorItem.getIsList();

            try {
                String value = extractValueFromSelector(doc, query, attribute, isList, baseUrl);
                if (value != null && !value.trim().isEmpty()) {
                    extractedData.put(name, value.trim());
                    log.debug("✅ Extract thành công {}: {}", name, value);
                } else {
                    log.warn("⚠️ Không tìm thấy dữ liệu cho selector: {}", name);
                }
            } catch (Exception e) {
                log.warn("⚠️ Lỗi khi extract selector {}: {}", name, e.getMessage());
            }
        }

        // Xử lý thủ công cho các trường đặc biệt nếu chưa có dữ liệu
        processManualExtraction(doc, extractedData);

        return extractedData;
    }

    /**
     * Xử lý thủ công cho các trường đặc biệt
     */
    private void processManualExtraction(Document doc, Map<String, String> extractedData) {
        // Tìm tất cả các thẻ p trong .movie-detail
        Elements movieDetailParagraphs = doc.select(".movie-detail p");

        for (Element p : movieDetailParagraphs) {
            String text = p.text();

            // Kiểm tra và xử lý Directors
            if (!extractedData.containsKey(SelectorMovieDetail.DIRECTORS.getValue()) && text.contains("Director:")) {
                String directorsValue = extractTextFromLinks(p.html());
                if (directorsValue != null && !directorsValue.trim().isEmpty()) {
                    extractedData.put(SelectorMovieDetail.DIRECTORS.getValue(), directorsValue.trim());
                    log.debug("✅ Extract thủ công directors: {}", directorsValue);
                }
            }

            // Kiểm tra và xử lý Actors
            if (!extractedData.containsKey(SelectorMovieDetail.ACTORS.getValue()) && text.contains("Actors:")) {
                String actorsValue = extractTextFromLinks(p.html());
                if (actorsValue != null && !actorsValue.trim().isEmpty()) {
                    extractedData.put(SelectorMovieDetail.ACTORS.getValue(), actorsValue.trim());
                    log.debug("✅ Extract thủ công actors: {}", actorsValue);
                }
            }

            // Kiểm tra và xử lý Countries
            if (!extractedData.containsKey(SelectorMovieDetail.COUNTRIES.getValue()) && text.contains("Country:")) {
                String countriesValue = extractTextFromLinks(p.html());
                if (countriesValue != null && !countriesValue.trim().isEmpty()) {
                    extractedData.put(SelectorMovieDetail.COUNTRIES.getValue(), countriesValue.trim());
                    log.debug("✅ Extract thủ công countries: {}", countriesValue);
                }
            }

            // Kiểm tra và xử lý Categories
            if (!extractedData.containsKey(SelectorMovieDetail.CATEGORY.getValue()) && text.contains("Genres:")) {
                String categoryValue = extractTextFromLinks(p.html());
                if (categoryValue != null && !categoryValue.trim().isEmpty()) {
                    extractedData.put(SelectorMovieDetail.CATEGORY.getValue(), categoryValue.trim());
                    log.debug("✅ Extract thủ công category: {}", categoryValue);
                }
            }

            // Kiểm tra và xử lý Trailer
            if (!extractedData.containsKey(SelectorMovieDetail.TRAILER.getValue()) && text.contains("Trailer:")) {
                String trailerValue = extractHrefFromLinks(p.html());
                if (trailerValue != null && !trailerValue.trim().isEmpty()) {
                    extractedData.put(SelectorMovieDetail.TRAILER.getValue(), trailerValue.trim());
                    log.debug("✅ Extract thủ công trailer: {}", trailerValue);
                }
            }
        }

        // Xử lý Release Year
        if (!extractedData.containsKey(SelectorMovieDetail.RELEASE_YEAR.getValue())) {
            Elements releaseElements = doc.select(".movie-detail span.title-year");
            if (!releaseElements.isEmpty()) {
                String releaseText = releaseElements.first().text();
                String yearValue = extractYearFromText(releaseText);
                if (yearValue != null && !yearValue.trim().isEmpty()) {
                    extractedData.put(SelectorMovieDetail.RELEASE_YEAR.getValue(), yearValue.trim());
                    log.debug("✅ Extract thủ công releaseYear: {}", yearValue);
                }
            }
        }
    }

    /**
     * Trích xuất href từ các thẻ <a> trong HTML
     */
    private String extractHrefFromLinks(String htmlContent) {
        if (htmlContent == null || htmlContent.isBlank())
            return htmlContent;

        // Tìm href attribute trong thẻ <a>
        java.util.regex.Pattern pattern = java.util.regex.Pattern.compile("href=[\"']([^\"']+)[\"']");
        java.util.regex.Matcher matcher = pattern.matcher(htmlContent);

        if (matcher.find()) {
            return matcher.group(1);
        }

        return null;
    }

    /**
     * Trích xuất năm từ text
     */
    private String extractYearFromText(String text) {
        if (text == null || text.isBlank())
            return null;

        // Tìm năm trong text (4 chữ số liên tiếp)
        Pattern pattern = Pattern.compile("\\b(19|20)\\d{2}\\b");
        Matcher matcher = pattern.matcher(text);
        if (matcher.find()) {
            return matcher.group();
        }

        return null;
    }

    /**
     * Trích xuất text từ các thẻ <a> trong HTML
     */
    private String extractTextFromLinks(String htmlContent) {
        if (htmlContent == null || htmlContent.isBlank())
            return htmlContent;

        // Tìm tất cả text content trong thẻ <a>
        java.util.regex.Pattern pattern = java.util.regex.Pattern.compile("<a[^>]*>([^<]+)</a>");
        java.util.regex.Matcher matcher = pattern.matcher(htmlContent);

        StringBuilder result = new StringBuilder();
        while (matcher.find()) {
            if (result.length() > 0) {
                result.append(", ");
            }
            result.append(matcher.group(1).trim());
        }

        // Nếu không tìm thấy thẻ <a>, trả về text gốc
        return result.length() > 0 ? result.toString() : htmlContent;
    }

    /**
     * Extract giá trị từ một selector cụ thể
     */
    private String extractValueFromSelector(Document doc, String query, String attribute, Boolean isList,
            String baseUrl) {
        if (isList != null && isList) {
            // Xử lý list elements
            Elements elements = doc.select(query);
            if (elements.isEmpty())
                return null;

            if (attribute != null && !attribute.isBlank()) {
                // Lấy attribute từ tất cả elements
                List<String> values = elements.stream()
                        .map(element -> element.attr(attribute))
                        .filter(val -> val != null && !val.isBlank())
                        .collect(Collectors.toList());
                return String.join(", ", values);
            } else {
                // Lấy text từ tất cả elements
                List<String> values = elements.stream()
                        .map(Element::text)
                        .filter(text -> text != null && !text.isBlank())
                        .collect(Collectors.toList());
                return String.join(", ", values);
            }
        } else {
            // Xử lý single element
            Element element = doc.selectFirst(query);
            if (element == null)
                return null;

            if (attribute != null && !attribute.isBlank()) {
                String value = element.attr(attribute);
                // Nếu là URL attribute, thêm domain nếu thiếu
                if (isUrlAttribute(attribute)) {
                    value = ensureFullUrl(value, baseUrl);
                }
                return value;
            } else {
                return element.text();
            }
        }
    }

    /**
     * Tìm hoặc tạo Movie dựa trên thumbnailUrl
     */
    private Movie findOrCreateMovie(Map<String, String> extractedData) {
        String thumbnailUrl = extractedData.get(SelectorMovieDetail.THUMBNAIL_URL.getValue());
        String title = extractedData.get(SelectorMovieDetail.TITLE.getValue());

        // Tìm existing movies một lần duy nhất để tránh duplicate query
        List<Movie> existingMovies = null;
        if (thumbnailUrl != null && !thumbnailUrl.isBlank()) {
            existingMovies = movieRepository.findByThumbnailUrl(thumbnailUrl);
        }

        // Nếu có existing movies, trả về movie có title ngắn nhất
        if (existingMovies != null && !existingMovies.isEmpty()) {
            Movie shortestTitleMovie = existingMovies.stream()
                    .min((m1, m2) -> Integer.compare(m1.getTitle().length(), m2.getTitle().length()))
                    .orElse(existingMovies.get(0));

            log.info("🔄 Tìm thấy movie có cùng thumbnailUrl: {}", shortestTitleMovie.getTitle());
            return shortestTitleMovie;
        }

        // Xác định MovieType dựa trên existing movies (nếu có)
        MovieType movieType = determineMovieTypeFromExistingMovies(existingMovies);

        // Tạo movie mới
        Movie movie = Movie.builder()
                .title(title != null ? title : "Unknown Title")
                .slug(generateSlugFromTitle(title))
                .content(extractedData.get(SelectorMovieDetail.DESCRIPTION.getValue()))
                .year(parseReleaseYear(extractedData.get(SelectorMovieDetail.RELEASE_YEAR.getValue())))
                .thumbnailUrl(thumbnailUrl)
                .posterUrl(extractedData.get("posterUrl"))
                .type(movieType)
                .trailerUrl(extractedData.get(SelectorMovieDetail.TRAILER.getValue()))
                .status(MovieStatus.UNKNOWN)
                .build();

        movie = movieRepository.save(movie);
        log.info("🆕 Tạo movie mới: {} với type: {}", movie.getTitle(), movieType);
        return movie;
    }

    /**
     * Xác định MovieType dựa trên existing movies (đã query trước đó)
     */
    private MovieType determineMovieTypeFromExistingMovies(List<Movie> existingMovies) {
        if (existingMovies != null && !existingMovies.isEmpty()) {
            // Nếu có cùng thumbnailUrl, là SERIES (nhiều tập cùng poster)
            log.info("🎬 Xác định movie type: SERIES (có cùng thumbnailUrl với {} movie khác)", existingMovies.size());
            return MovieType.SERIES;
        }

        // Mặc định là SINGLE
        log.info("🎬 Xác định movie type: SINGLE (không có cùng thumbnailUrl)");
        return MovieType.SINGLE;
    }

    /**
     * Lưu các entity liên quan
     */
    private void saveRelatedEntities(Movie movie, Map<String, String> extractedData, String baseUrl) {
        // Lưu Actors
        saveActors(movie, extractedData.get(SelectorMovieDetail.ACTORS.getValue()));

        // Lưu Categories
        saveCategories(movie, extractedData.get(SelectorMovieDetail.CATEGORY.getValue()));

        // Lưu Countries
        saveCountries(movie, extractedData.get(SelectorMovieDetail.COUNTRIES.getValue()));

        // Lưu Directors
        saveDirectors(movie, extractedData.get(SelectorMovieDetail.ACTORS.getValue()));

        // Lưu Episodes và ServerDatas
        saveEpisodesAndServerDatas(movie, extractedData);
    }

    /**
     * Lưu Actors
     */
    private void saveActors(Movie movie, String actorsData) {
        if (actorsData == null || actorsData.isBlank())
            return;

        Set<Actor> actors = new HashSet<>();
        String[] actorNames = actorsData.split(",");

        for (String actorName : actorNames) {
            String name = actorName.trim();
            // Kiểm tra kỹ hơn để tránh actor rỗng
            if (name != null && !name.isEmpty() && !name.isBlank()) {
                String slug = generateSlugFromName(name);
                // Kiểm tra slug có hợp lệ không
                if (slug != null && !slug.isEmpty() && !slug.equals("unknown")) {
                    // Tìm actor đã tồn tại hoặc tạo mới
                    Actor actor = actorRepository.findByName(name)
                            .orElseGet(() -> {
                                Actor newActor = Actor.builder()
                                        .name(name)
                                        .slug(slug)
                                        .build();
                                log.debug("🆕 Tạo actor mới: {} -> {}", name, slug);
                                return newActor;
                            });

                    actors.add(actor);
                    log.debug("✅ Thêm actor: {} -> {}", name, actor.getSlug());
                } else {
                    log.warn("⚠️ Bỏ qua actor có slug không hợp lệ: {}", name);
                }
            } else {
                log.warn("⚠️ Bỏ qua actor rỗng: '{}'", actorName);
            }
        }

        if (!actors.isEmpty()) {
            // Chỉ save những actor mới (chưa có id)
            List<Actor> newActors = actors.stream()
                    .filter(actor -> actor.getId() == null)
                    .collect(Collectors.toList());

            if (!newActors.isEmpty()) {
                actorRepository.saveAll(newActors);
                log.info("✅ Lưu {} actors mới", newActors.size());
            }

            movie.setActors(actors);
            log.info("✅ Tổng cộng {} actors cho movie", actors.size());
        } else {
            log.warn("⚠️ Không có actor nào hợp lệ để lưu");
        }
    }

    /**
     * Lưu Categories
     */
    private void saveCategories(Movie movie, String categoryData) {
        if (categoryData == null || categoryData.isBlank())
            return;

        Set<Category> categories = new HashSet<>();
        String[] categoryNames = categoryData.split(",");

        for (String categoryName : categoryNames) {
            String name = categoryName.trim();
            // Kiểm tra kỹ hơn để tránh category rỗng
            if (name != null && !name.isEmpty() && !name.isBlank()) {
                String slug = generateSlugFromName(name);
                // Kiểm tra slug có hợp lệ không
                if (slug != null && !slug.isEmpty() && !slug.equals("unknown")) {
                    // Tìm category đã tồn tại hoặc tạo mới
                    Category category = categoryRepository.findByName(name)
                            .orElseGet(() -> {
                                Category newCategory = Category.builder()
                                        .name(name)
                                        .slug(slug)
                                        .build();
                                log.debug("🆕 Tạo category mới: {} -> {}", name, slug);
                                return newCategory;
                            });

                    categories.add(category);
                    log.debug("✅ Thêm category: {} -> {}", name, category.getSlug());
                } else {
                    log.warn("⚠️ Bỏ qua category có slug không hợp lệ: {}", name);
                }
            } else {
                log.warn("⚠️ Bỏ qua category rỗng: '{}'", categoryName);
            }
        }

        if (!categories.isEmpty()) {
            // Chỉ save những category mới (chưa có id)
            List<Category> newCategories = categories.stream()
                    .filter(cat -> cat.getId() == null)
                    .collect(Collectors.toList());

            if (!newCategories.isEmpty()) {
                categoryRepository.saveAll(newCategories);
                log.info("✅ Lưu {} categories mới", newCategories.size());
            }

            movie.setCategories(categories);
            log.info("✅ Tổng cộng {} categories cho movie", categories.size());
        } else {
            log.warn("⚠️ Không có category nào hợp lệ để lưu");
        }
    }

    /**
     * Lưu Countries
     */
    private void saveCountries(Movie movie, String countriesData) {
        if (countriesData == null || countriesData.isBlank())
            return;

        Set<Country> countries = new HashSet<>();
        String[] countryNames = countriesData.split(",");

        for (String countryName : countryNames) {
            String name = countryName.trim();
            // Kiểm tra kỹ hơn để tránh country rỗng
            if (name != null && !name.isEmpty() && !name.isBlank()) {
                String slug = generateSlugFromName(name);
                // Kiểm tra slug có hợp lệ không
                if (slug != null && !slug.isEmpty() && !slug.equals("unknown")) {
                    // Tìm country đã tồn tại hoặc tạo mới
                    Country country = countryRepository.findByName(name)
                            .orElseGet(() -> {
                                Country newCountry = Country.builder()
                                        .name(name)
                                        .slug(slug)
                                        .build();
                                log.debug("🆕 Tạo country mới: {} -> {}", name, slug);
                                return newCountry;
                            });

                    countries.add(country);
                    log.debug("✅ Thêm country: {} -> {}", name, country.getSlug());
                } else {
                    log.warn("⚠️ Bỏ qua country có slug không hợp lệ: {}", name);
                }
            } else {
                log.warn("⚠️ Bỏ qua country rỗng: '{}'", countryName);
            }
        }

        if (!countries.isEmpty()) {
            // Chỉ save những country mới (chưa có id)
            List<Country> newCountries = countries.stream()
                    .filter(country -> country.getId() == null)
                    .collect(Collectors.toList());

            if (!newCountries.isEmpty()) {
                countryRepository.saveAll(newCountries);
                log.info("✅ Lưu {} countries mới", newCountries.size());
            }

            movie.setCountries(countries);
            log.info("✅ Tổng cộng {} countries cho movie", countries.size());
        } else {
            log.warn("⚠️ Không có country nào hợp lệ để lưu");
        }
    }

    /**
     * Lưu Directors
     */
    private void saveDirectors(Movie movie, String directorsData) {
        if (directorsData == null || directorsData.isBlank())
            return;

        Set<Director> directors = new HashSet<>();
        String[] directorNames = directorsData.split(",");

        for (String directorName : directorNames) {
            String name = directorName.trim();
            // Kiểm tra kỹ hơn để tránh director rỗng
            if (name != null && !name.isEmpty() && !name.isBlank()) {
                String slug = generateSlugFromName(name);
                // Kiểm tra slug có hợp lệ không
                if (slug != null && !slug.isEmpty() && !slug.equals("unknown")) {
                    // Tìm director đã tồn tại hoặc tạo mới
                    Director director = directorRepository.findByName(name)
                            .orElseGet(() -> {
                                Director newDirector = Director.builder()
                                        .name(name)
                                        .slug(slug)
                                        .build();
                                log.debug("🆕 Tạo director mới: {} -> {}", name, slug);
                                return newDirector;
                            });

                    directors.add(director);
                    log.debug("✅ Thêm director: {} -> {}", name, director.getSlug());
                } else {
                    log.warn("⚠️ Bỏ qua director có slug không hợp lệ: {}", name);
                }
            } else {
                log.warn("⚠️ Bỏ qua director rỗng: '{}'", directorName);
            }
        }

        if (!directors.isEmpty()) {
            // Chỉ save những director mới (chưa có id)
            List<Director> newDirectors = directors.stream()
                    .filter(director -> director.getId() == null)
                    .collect(Collectors.toList());

            if (!newDirectors.isEmpty()) {
                directorRepository.saveAll(newDirectors);
                log.info("✅ Lưu {} directors mới", newDirectors.size());
            }

            movie.setDirectors(directors);
            log.info("✅ Tổng cộng {} directors cho movie", directors.size());
        } else {
            log.warn("⚠️ Không có director nào hợp lệ để lưu");
        }
    }

    /**
     * Lưu Episodes và ServerDatas
     */
    private void saveEpisodesAndServerDatas(Movie movie, Map<String, String> extractedData) {
        String videoUrl = extractedData.get(SelectorMovieDetail.VIDEO_URL.getValue());

        if (videoUrl != null && !videoUrl.isBlank()) {
            // Tạo episode cho video chính
            Episode episode = Episode.builder()
                    .serverName("Full")
                    .movie(movie)
                    .build();

            episode = episodeRepository.save(episode);

            // Tạo Server Data
            ServerData serverData = ServerData.builder()
                    .episode(episode)
                    .name(movie.getTitle())
                    .slug(movie.getSlug())
                    .filename(movie.getTitle())
                    .link_embed(videoUrl)
                    .link_m3u8(getLinkM3U8(videoUrl))
                    .build();

            serverDataRepository.save(serverData);
            log.info("✅ Lưu episode và Server Data");
        }
    }

    private String getLinkM3U8(String videoUrl) {
        if (videoUrl == null || videoUrl.isBlank()) {
            log.warn("⚠️ Video URL không được để trống");
            return null;
        }

        try {
            // Kiểm tra xem có phải embed link không
            if (StringUtils.isNullOrBlank(videoUrl)) {
                log.info("ℹ️ Video URL không phải embed link: {}", videoUrl);
                return null;
            }

            // Tải M3U8 video
            log.info("🚀 Bắt đầu tải M3U8 video cho: {}", videoUrl);
            m3U8DownloadService.downloadM3U8Video(videoUrl);

            // Trích xuất ID từ embed link
            String id = m3U8DownloadService.extractIdFromEmbedLink(videoUrl);

            // Tạo đường dẫn local M3U8
            String localM3U8Path = String.format("local_copy/newplaylist/%s/%s.m3u8", id, id);
            log.info("✅ Đã tạo local M3U8 path: {}", localM3U8Path);

            return localM3U8Path;

        } catch (Exception e) {
            log.error("❌ Lỗi khi tạo M3U8 link từ video URL: {}", videoUrl, e);
            return null;
        }
    }

    /**
     * Helper methods
     */
    private String generateSlugFromTitle(String title) {
        if (title == null || title.trim().isEmpty()) {
            return "unknown-" + System.currentTimeMillis();
        }

        // Xử lý tiếng Thái và các ký tự Unicode
        String slug = title.toLowerCase()
                // Giữ lại chữ cái tiếng Thái, chữ cái Latin, số, khoảng trắng và dấu gạch ngang
                .replaceAll("[^\\u0E00-\\u0E7F\\u0E80-\\u0EFFa-z0-9\\s-]", "")
                .replaceAll("\\s+", "-")
                .replaceAll("-+", "-")
                .replaceAll("^-|-$", "");

        // Kiểm tra slug có hợp lệ không
        if (slug == null || slug.isEmpty() || slug.isBlank()) {
            return "unknown-" + System.currentTimeMillis();
        }

        // Nếu slug chỉ có dấu gạch ngang, trả về unknown với timestamp
        if (slug.replaceAll("-", "").isEmpty()) {
            return "unknown-" + System.currentTimeMillis();
        }

        return slug;
    }

    private String generateSlugFromName(String name) {
        if (name == null || name.trim().isEmpty()) {
            return "unknown";
        }

        // Xử lý tiếng Thái và các ký tự Unicode
        String slug = name.toLowerCase()
                // Giữ lại chữ cái tiếng Thái, chữ cái Latin, số, khoảng trắng và dấu gạch ngang
                .replaceAll("[^\\u0E00-\\u0E7F\\u0E80-\\u0EFFa-z0-9\\s-]", "")
                .replaceAll("\\s+", "-")
                .replaceAll("-+", "-")
                .replaceAll("^-|-$", "");

        // Kiểm tra slug có hợp lệ không
        if (slug == null || slug.isEmpty() || slug.isBlank()) {
            return "unknown";
        }

        // Nếu slug chỉ có dấu gạch ngang, trả về unknown
        if (slug.replaceAll("-", "").isEmpty()) {
            return "unknown";
        }

        return slug;
    }

    private Integer parseReleaseYear(String yearStr) {
        if (yearStr == null || yearStr.isBlank())
            return null;

        try {
            return Integer.parseInt(yearStr.trim());
        } catch (NumberFormatException e) {
            log.warn("⚠️ Không thể parse release year: {}", yearStr);
            return null;
        }
    }

    private boolean isUrlAttribute(String attribute) {
        if (attribute == null)
            return false;

        String lowerAttr = attribute.toLowerCase();
        return lowerAttr.equals("href") ||
                lowerAttr.equals("src") ||
                lowerAttr.equals("data-src") ||
                lowerAttr.equals("data-original") ||
                lowerAttr.equals("data-lazy-src") ||
                lowerAttr.equals("data-url") ||
                lowerAttr.equals("url") ||
                lowerAttr.equals("link") ||
                lowerAttr.startsWith("data-") && lowerAttr.contains("url");
    }

    private String ensureFullUrl(String url, String baseUrl) {
        if (url == null || url.isBlank()) {
            return url;
        }

        // Nếu URL đã có protocol (http/https), trả về nguyên bản
        if (url.startsWith("http://") || url.startsWith("https://")) {
            return url;
        }

        try {
            // Lấy domain từ baseUrl
            java.net.URI baseUri = new java.net.URI(baseUrl);
            String domain = baseUri.getScheme() + "://" + baseUri.getHost();

            // Nếu URL bắt đầu bằng /, thêm domain vào trước
            if (url.startsWith("/")) {
                return domain + url;
            }

            // Nếu URL không bắt đầu bằng /, thêm domain và / vào trước
            return domain + "/" + url;
        } catch (java.net.URISyntaxException e) {
            log.warn("Không thể parse baseUrl: {}", baseUrl);
            return url;
        }
    }
}
