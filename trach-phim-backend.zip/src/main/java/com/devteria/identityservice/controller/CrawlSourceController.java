package com.devteria.identityservice.controller;

import com.devteria.identityservice.dto.request.ApiResponse;
import com.devteria.identityservice.dto.request.CrawlSourceRequest;
import com.devteria.identityservice.dto.request.SitemapCrawlRequest;
import com.devteria.identityservice.dto.response.BulkInsertResponse;
import com.devteria.identityservice.dto.response.CrawlSourceResponse;
import com.devteria.identityservice.dto.response.MovieResponse;
import com.devteria.identityservice.dto.response.SitemapCrawlResponse;
import com.devteria.identityservice.service.CrawlSourceService;
import com.devteria.identityservice.service.SitemapCrawlerService;
import com.devteria.identityservice.service.M3U8DownloadService;
import jakarta.validation.Valid;
import java.util.List;
import java.util.Map;
import java.util.HashMap;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.io.IOException;
import lombok.extern.slf4j.Slf4j;
import lombok.AccessLevel;
import lombok.RequiredArgsConstructor;
import lombok.experimental.FieldDefaults;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/crawl-sources")
@RequiredArgsConstructor
@FieldDefaults(level = AccessLevel.PRIVATE, makeFinal = true)
@Slf4j
public class CrawlSourceController {
    CrawlSourceService service;
    SitemapCrawlerService sitemapCrawlerService;
    M3U8DownloadService m3U8DownloadService;

    @PostMapping
    ApiResponse<CrawlSourceResponse> create(@RequestBody @Valid CrawlSourceRequest request) {
        return ApiResponse.<CrawlSourceResponse>builder().result(service.create(request)).build();
    }

    @PutMapping("/{id}")
    ApiResponse<CrawlSourceResponse> update(@PathVariable String id, @RequestBody @Valid CrawlSourceRequest request) {
        return ApiResponse.<CrawlSourceResponse>builder().result(service.update(id, request)).build();
    }

    @GetMapping("/{id}")
    ApiResponse<CrawlSourceResponse> get(@PathVariable String id) {
        return ApiResponse.<CrawlSourceResponse>builder().result(service.get(id)).build();
    }

    @DeleteMapping("/{id}")
    ApiResponse<String> delete(@PathVariable String id) {
        service.delete(id);
        return ApiResponse.<String>builder().result("Deleted").build();
    }

    @PostMapping("/crawl-sitemap/large-scale")
    ApiResponse<SitemapCrawlResponse> crawlSitemapLargeScale(@RequestBody @Valid SitemapCrawlRequest request) {
        return ApiResponse.<SitemapCrawlResponse>builder()
                .result(sitemapCrawlerService.crawlSitemapWithSelector(request, true)).build();
    }

    @PostMapping("/insert-movies-by-ids")
    ApiResponse<BulkInsertResponse> insertMoviesFromCrawlSourceIds(@RequestBody List<String> crawlSourceIds) {
        BulkInsertResponse response = service.insertFromCrawlSourceIds(crawlSourceIds);
        return ApiResponse.<BulkInsertResponse>builder().result(response).build();
    }

}
