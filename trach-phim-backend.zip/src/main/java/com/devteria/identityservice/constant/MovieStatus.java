package com.devteria.identityservice.constant;

public enum MovieStatus {
    COMPLETED,
    ONGOING,
    UNKNOWN
}


