package com.devteria.identityservice.constant;

public enum MovieType {
    SERIES,
    SINGLE
}


