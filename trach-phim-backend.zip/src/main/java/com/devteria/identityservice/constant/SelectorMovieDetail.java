package com.devteria.identityservice.constant;

import lombok.Getter;

@Getter
public enum SelectorMovieDetail {
    TITLE("TITLE"),
    DESCRIPTION("DESCRIPTION"),
    TRAILER("TRAILER"),
    ACTORS("ACTORS"),
    CATEGORY("CATEGORY"),
    COUNTRIES("COUNTRIES"),
    DIRECTORS("DIRECTORS"),
    THUMBNAIL_URL("THUMBNAIL_URL"),
    RELEASE_YEAR("RELEASE_YEAR"),
    POSTER_URL("POSTER_URL"),
    VIDEO_URL("VIDEO_URL"),
    ;

    private final String value;

    SelectorMovieDetail(String value) {
        this.value = value;
    }

}
