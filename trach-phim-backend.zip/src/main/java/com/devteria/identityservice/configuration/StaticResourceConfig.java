// package com.devteria.identityservice.configuration;

// import org.springframework.context.annotation.Configuration;
// import
// org.springframework.web.servlet.config.annotation.ResourceHandlerRegistry;
// import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

// @Configuration
// public class StaticResourceConfig implements WebMvcConfigurer {

// @Override
// public void addResourceHandlers(ResourceHandlerRegistry registry) {
// // Serve files từ thư mục local_copy
// registry.addResourceHandler("/local_copy/**")
// .addResourceLocations("file:local_copy/");

// // Serve files từ thư mục txt (nếu có)
// registry.addResourceHandler("/txt/**")
// .addResourceLocations("file:txt/");

// // Serve files từ thư mục m3u8 (nếu có)
// registry.addResourceHandler("/m3u8/**")
// .addResourceLocations("file:m3u8/");
// }
// }
