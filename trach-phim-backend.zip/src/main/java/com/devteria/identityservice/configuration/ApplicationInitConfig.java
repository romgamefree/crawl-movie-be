package com.devteria.identityservice.configuration;

import java.util.HashSet;
import java.util.Set;

import com.devteria.identityservice.entity.Selector;
import com.devteria.identityservice.entity.SelectorItem;
import com.devteria.identityservice.repository.SelectorItemRepository;
import com.devteria.identityservice.repository.SelectorRepository;
import org.springframework.boot.ApplicationRunner;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.crypto.password.PasswordEncoder;

import com.devteria.identityservice.constant.PredefinedRole;
import com.devteria.identityservice.entity.Role;
import com.devteria.identityservice.entity.User;
import com.devteria.identityservice.repository.RoleRepository;
import com.devteria.identityservice.repository.UserRepository;

import lombok.AccessLevel;
import lombok.RequiredArgsConstructor;
import lombok.experimental.FieldDefaults;
import lombok.experimental.NonFinal;
import lombok.extern.slf4j.Slf4j;

@Configuration
@RequiredArgsConstructor
@FieldDefaults(level = AccessLevel.PRIVATE, makeFinal = true)
@Slf4j
public class ApplicationInitConfig {

    PasswordEncoder passwordEncoder;

    @NonFinal
    static final String ADMIN_USER_NAME = "admin";

    @NonFinal
    static final String ADMIN_PASSWORD = "admin";

    @Bean
    @ConditionalOnProperty(
            prefix = "spring",
            value = "datasource.driverClassName",
            havingValue = "com.mysql.cj.jdbc.Driver")
    ApplicationRunner applicationRunner(UserRepository userRepository, RoleRepository roleRepository, SelectorRepository selectorRepository, SelectorItemRepository selectorItemRepository) {
        log.info("Initializing application.....");
        return args -> {
            if (userRepository.findByUsername(ADMIN_USER_NAME).isEmpty()) {
                log.info("Creating admin user...");
                roleRepository.save(Role.builder()
                        .name(PredefinedRole.USER_ROLE)
                        .description("User role")
                        .build());

                Role adminRole = roleRepository.save(Role.builder()
                        .name(PredefinedRole.ADMIN_ROLE)
                        .description("Admin role")
                        .build());

                var roles = new HashSet<Role>();
                roles.add(adminRole);

                User user = User.builder()
                        .username(ADMIN_USER_NAME)
                        .password(passwordEncoder.encode(ADMIN_PASSWORD))
                        .roles(roles)
                        .build();

                userRepository.save(user);
                log.warn("admin user has been created with default password: admin, please change it");
            }
            if(selectorRepository.findAll().isEmpty()) {
                log.info("Creating default selector...");
                
                // Tạo Selector trước
                Selector selector = selectorRepository.save(Selector.builder()
                        .name("123hd")
                        .note("system default selector")
                        .build());
                
                // Sau đó tạo SelectorItem với reference đến Selector
                SelectorItem descriptionSelector = selectorItemRepository.save(SelectorItem.builder()
                        .selector(selector)
                        .name("DESCRIPTION")
                        .query("meta[name=description]")
                        .note("system default selector")
                        .build());

                SelectorItem titleSelector = selectorItemRepository.save(SelectorItem.builder()
                        .selector(selector)
                        .name("TITLE")
                        .query("h1.entry-title a")
                        .note("system default selector")
                        .build());

                SelectorItem videoUrlSelector = selectorItemRepository.save(SelectorItem.builder()
                        .selector(selector)
                        .name("VIDEO_URL")
                        .query(".embed-responsive-item")
                        .attribute("src")
                        .note("system default selector")
                        .build());

                SelectorItem thumbnailUrlSelector = selectorItemRepository.save(SelectorItem.builder()
                        .selector(selector)
                        .name("THUMBNAIL_URL")
                        .query("#content > div > div.halim-movie-wrapper.tpl-2 > div.movie_info.col-xs-12 > div.movie-poster.col-md-4 > img")
                        .attribute("src")
                        .note("system default selector")
                        .build());

                log.info("Default selector has been created");
            }
            log.info("Application initialization completed .....");
        };
    }

}
