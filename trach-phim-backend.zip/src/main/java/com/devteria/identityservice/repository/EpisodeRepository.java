package com.devteria.identityservice.repository;

import com.devteria.identityservice.entity.Episode;
import org.springframework.data.jpa.repository.JpaRepository;

public interface EpisodeRepository extends JpaRepository<Episode, String> {}


