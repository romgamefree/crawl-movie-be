package com.devteria.identityservice.repository;

import com.devteria.identityservice.entity.Created;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CreatedRepository extends JpaRepository<Created, String> {}


