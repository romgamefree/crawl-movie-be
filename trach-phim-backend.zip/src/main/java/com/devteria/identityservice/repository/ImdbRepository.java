package com.devteria.identityservice.repository;

import com.devteria.identityservice.entity.Imdb;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ImdbRepository extends JpaRepository<Imdb, String> {}


