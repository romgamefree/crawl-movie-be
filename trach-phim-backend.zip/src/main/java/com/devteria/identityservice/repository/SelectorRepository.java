package com.devteria.identityservice.repository;

import com.devteria.identityservice.entity.Selector;
import org.springframework.data.jpa.repository.JpaRepository;

public interface SelectorRepository extends JpaRepository<Selector, String> {}


