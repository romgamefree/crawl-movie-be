package com.devteria.identityservice.repository;

import com.devteria.identityservice.entity.Modified;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ModifiedRepository extends JpaRepository<Modified, String> {}


