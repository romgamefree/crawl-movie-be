package com.devteria.identityservice.utils;

import lombok.extern.slf4j.Slf4j;

import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

@Slf4j
public class FileUtils {

    /**
     * Lưu nội dung text vào file
     */
    public static void saveFileContent(String savePath, String content) {
        try {
            Path path = Paths.get(savePath);
            Files.createDirectories(path.getParent());
            Files.write(path, content.getBytes());
            log.debug("✅ Đã lưu nội dung vào: {}", savePath);
        } catch (Exception e) {
            log.error("❌ Lỗi khi lưu nội dung vào {}: {}", savePath, e.getMessage());
            throw new RuntimeException("Failed to save content to " + savePath, e);
        }
    }

    /**
     * Lưu bytes vào file
     */
    public static void saveFileBytes(String savePath, byte[] bytes) {
        try {
            Path path = Paths.get(savePath);
            Files.createDirectories(path.getParent());

            if (Files.exists(path)) {
                log.info("⏭️ File đã tồn tại: {}", savePath);
                return;
            }

            Files.write(path, bytes);
            log.debug("✅ Đã lưu file: {}", savePath);
        } catch (Exception e) {
            log.error("❌ Lỗi khi lưu file {}: {}", savePath, e.getMessage());
            throw new RuntimeException("Failed to save file to " + savePath, e);
        }
    }

    /**
     * Tạo thư mục nếu chưa tồn tại
     */
    public static void createDirectories(String filePath) {
        try {
            Path path = Paths.get(filePath);
            Files.createDirectories(path.getParent());
        } catch (Exception e) {
            log.error("❌ Lỗi khi tạo thư mục cho {}: {}", filePath, e.getMessage());
            throw new RuntimeException("Failed to create directories for " + filePath, e);
        }
    }

    /**
     * Kiểm tra file có tồn tại không
     */
    public static boolean fileExists(String filePath) {
        return Files.exists(Paths.get(filePath));
    }
}
