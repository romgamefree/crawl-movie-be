package com.devteria.identityservice.utils;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public class StringUtils {

    /**
     * Kiểm tra string có null hoặc blank không
     */
    public static boolean isNullOrBlank(String str) {
        return str == null || str.isBlank();
    }

    /**
     * Kiểm tra string có null hoặc empty không
     */
    public static boolean isNullOrEmpty(String str) {
        return str == null || str.isEmpty();
    }

    /**
     * Tạo metadata string từ title và description
     */
    public static String buildMetadataString(String title, String description) {
        StringBuilder sb = new StringBuilder();
        if (!isNullOrBlank(title)) {
            sb.append("Title: ").append(title.trim());
        }
        if (!isNullOrBlank(description)) {
            if (sb.length() > 0) {
                sb.append("\n");
            }
            sb.append("Description: ").append(description.trim());
        }
        return sb.toString();
    }

    /**
     * Truncate string với độ dài tối đa
     */
    public static String truncate(String str, int maxLength) {
        if (isNullOrEmpty(str)) {
            return str;
        }
        if (str.length() <= maxLength) {
            return str;
        }
        return str.substring(0, maxLength) + "...";
    }

    /**
     * Clean và normalize string
     */
    public static String cleanString(String str) {
        if (isNullOrEmpty(str)) {
            return str;
        }
        return str.trim()
                .replaceAll("\\s+", " ")
                .replaceAll("[\\r\\n\\t]", " ");
    }
}
